# AthleteHuddle — Integration & Setup Guide

## Overview

AthleteHuddle is a module inside the HomeHuddle / Venuewise ecosystem. It is **not** a separate login or product — every AthleteHuddle feature is accessible from the parent's HomeHuddle account.

---

## File Structure

```
/athletehuddle.html            Landing page / marketing
/athlete-onboarding.html       Create athlete profile
/family-athletes.html          Parent view — all athletes
/athlete-dashboard.html        Individual athlete dashboard
/athlete-calendar-link.html    Assign calendar events to athletes
/athlete-public-profile.html   Shareable athlete profile (private by default)
/athletehuddle.js              Shared JS library — all Supabase operations
/supabase-schema.sql           Complete database schema
```

---

## Step 1 — Supabase Setup

1. Open your Supabase project dashboard.
2. Go to **SQL Editor**.
3. Run `supabase-schema.sql` in full.
4. Confirm these tables exist:
   - `families`
   - `athletes`
   - `athlete_sports`
   - `athlete_events`
   - `athlete_goals`
   - `athlete_stats`
   - `athlete_videos`
   - `coach_connections`
5. Enable **Row Level Security** (already included in schema).
6. Review RLS policies and adjust `auth.uid()` to match your HomeHuddle auth mechanism.

---

## Step 2 — Configure Supabase Keys

In each HTML file (or in a shared `config.js`), set your Supabase credentials **before** loading `athletehuddle.js`:

```html
<script>
  window.SUPABASE_URL = 'https://YOUR_PROJECT.supabase.co';
  window.SUPABASE_ANON_KEY = 'YOUR_ANON_KEY';
</script>
<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
<script src="athletehuddle.js"></script>
```

For production, move these to a server-side environment variable or Supabase Edge Function — never hardcode secret keys in client HTML.

---

## Step 3 — Auth Integration

AthleteHuddle uses the **same auth session** as HomeHuddle. The `athletehuddle.js` library calls `db.auth.getSession()` to get the current user.

### If HomeHuddle uses Supabase Auth (email/password or magic link):
No changes needed. Sessions carry over automatically.

### If HomeHuddle uses email/PIN (custom auth):
When a user logs in via PIN, call Supabase's `signInWithPassword()` or your custom JWT sign-in and store the session. Then `getSession()` in `athletehuddle.js` will work.

### Family ID Linkage
The `families` table uses `email` as the join key. When a HomeHuddle user logs in, their email maps to a `families` row. If your `families` table already exists in HomeHuddle, add the AthleteHuddle-specific columns or create a separate `ah_families` view.

---

## Step 4 — HomeHuddle Navigation Integration

Add these links to your existing HomeHuddle dashboard navigation:

```html
<!-- In your HomeHuddle nav or sidebar -->
<a href="/my-athletes">🏅 My Athletes</a>
<a href="/add-athlete">➕ Add Athlete</a>
<a href="/athlete-calendar">📅 Athlete Calendar</a>
```

Or map the routes to the AthleteHuddle HTML files if serving statically from GitHub Pages.

---

## Step 5 — Calendar Event Linking

HomeHuddle calendar events have IDs. AthleteHuddle stores those IDs in `athlete_events.event_id`.

**Linking flow:**
1. Parent views their HomeHuddle calendar
2. On the `athlete-calendar-link.html` page, load calendar events from HomeHuddle's events table
3. Parent clicks athlete name buttons to assign events
4. On save, `linkEventToAthlete()` creates rows in `athlete_events`

**To load real HomeHuddle events**, replace the `sampleEvents` demo array in `athlete-calendar-link.html` with a Supabase query to your existing events table:

```javascript
const { data: events } = await db
  .from('calendar_events')          // your HomeHuddle events table name
  .select('*')
  .eq('family_id', familyId)
  .gte('start_time', new Date().toISOString())
  .order('start_time')
  .limit(30);
```

---

## Step 6 — Subscription / Plan Gating

AthleteHuddle is included in both plans. To gate access:

```javascript
async function checkAthleteAccess() {
  const family = await getCurrentFamily();
  if (!family) return false;
  return ['founding', 'standard'].includes(family.plan_type)
    && family.subscription_status === 'active';
}
```

Call this on page load and redirect to `/pricing` or HomeHuddle upgrade page if it returns `false`.

Plan pricing reference:
- **Founding Family**: $4.95/month (grandfathered, locked forever)
- **Standard Family**: $9.99/month

---

## Step 7 — Photo Upload (MVP → Production)

In MVP, parents paste a photo URL or the URL is stored as a placeholder.

For production photo upload:
1. Create a Supabase Storage bucket named `athlete-photos`
2. Set bucket to private
3. On file select in `athlete-onboarding.html`, upload with:

```javascript
const { data, error } = await db.storage
  .from('athlete-photos')
  .upload(`${familyId}/${athleteId}.jpg`, file, {
    cacheControl: '3600',
    upsert: true
  });

const { data: urlData } = db.storage
  .from('athlete-photos')
  .getPublicUrl(`${familyId}/${athleteId}.jpg`);

// Save URL to athlete profile
await updateAthlete(athleteId, { profile_photo_url: urlData.publicUrl });
```

---

## AI Video Analysis — Future Integration

The `athlete_videos` table includes:
- `ai_analysis_status`: `not_submitted | pending | processing | complete | failed`
- `ai_analysis_notes`: text field for AI output

When AI analysis launches:
1. Parent clicks "Submit for AI Analysis" button
2. Video URL is sent to your AI analysis service (biomechanics API, OpenAI Vision, etc.)
3. Status updates to `pending` → `processing` → `complete`
4. Results written to `ai_analysis_notes`

The UI placeholder is already in `athlete-dashboard.html` video cards.

---

## CoachesHuddle — Future Integration

The `coach_connections` table supports:
- Storing coach name, email, sport, organization
- `connection_status`: pending → active
- `permissions` JSONB: granular access control per connection

When CoachesHuddle launches:
1. `coach_id` column links to the coaches database
2. Coaches can log in and see connected athlete profiles (with permission)
3. They can push goals, events, and video feedback back to the athlete
4. `athlete_events` accepts `source: 'coacheshuddle'` for coach-created events

---

## Deployment — GitHub Pages

1. Push all files to your GitHub repo under the correct path
2. Enable GitHub Pages in repo settings (branch: `main`, folder: `/` or `/docs`)
3. Access via `https://yourusername.github.io/repo-name/athletehuddle.html`

For custom domain (`app.venuewise.com`):
1. Add a `CNAME` file with your domain
2. Configure DNS with your registrar

---

## Security Checklist

- [ ] RLS enabled on all tables (included in schema)
- [ ] Supabase anon key only — never service_role key in client
- [ ] `is_public = FALSE` is the default for all athlete profiles
- [ ] Contact info hidden unless parent explicitly enables sharing
- [ ] Coach connections require parent approval before coach can view profile
- [ ] No PII (email, phone) exposed in public profile view

---

## MVP Priority Checklist

- [x] Supabase schema (all 8 tables)
- [x] Athlete onboarding page
- [x] Family athletes page
- [x] Athlete dashboard
- [x] Calendar event linking page
- [x] Public/private profile page
- [x] Shared JS library with all CRUD operations
- [ ] Connect to live Supabase project (add keys)
- [ ] Wire real HomeHuddle calendar events into calendar link page
- [ ] Map HomeHuddle family login session to `families` table
- [ ] Add subscription gate
- [ ] Production photo upload via Supabase Storage
- [ ] Add AthleteHuddle nav links to HomeHuddle dashboard

---

*AthleteHuddle — Part of the Venuewise Ecosystem*
*HomeHuddle · AthleteHuddle · CoachesHuddle (coming soon)*
