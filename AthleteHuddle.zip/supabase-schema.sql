-- ============================================================
-- AthleteHuddle Supabase Schema
-- Part of the Venuewise / HomeHuddle Ecosystem
-- ============================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================================
-- 1. FAMILIES
-- ============================================================
CREATE TABLE IF NOT EXISTS families (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  parent_name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  phone TEXT,
  subscription_status TEXT DEFAULT 'active' CHECK (subscription_status IN ('active','inactive','trial','cancelled')),
  plan_type TEXT DEFAULT 'standard' CHECK (plan_type IN ('founding','standard','trial')),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- 2. ATHLETES
-- ============================================================
CREATE TABLE IF NOT EXISTS athletes (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  family_id UUID NOT NULL REFERENCES families(id) ON DELETE CASCADE,
  first_name TEXT NOT NULL,
  last_name TEXT NOT NULL,
  birthdate DATE,
  graduation_year INT,
  gender TEXT CHECK (gender IN ('male','female','non-binary','prefer_not_to_say')),
  city TEXT,
  state TEXT,
  profile_photo_url TEXT,
  primary_sport TEXT,
  secondary_sports TEXT[], -- array of sport names
  height_inches NUMERIC(5,2),
  weight_lbs NUMERIC(6,2),
  dominant_hand TEXT CHECK (dominant_hand IN ('right','left','ambidextrous')),
  dominant_foot TEXT CHECK (dominant_foot IN ('right','left','ambidextrous')),
  school TEXT,
  is_public BOOLEAN DEFAULT FALSE, -- privacy: private by default
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_athletes_family_id ON athletes(family_id);

-- ============================================================
-- 3. ATHLETE SPORTS
-- ============================================================
CREATE TABLE IF NOT EXISTS athlete_sports (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  athlete_id UUID NOT NULL REFERENCES athletes(id) ON DELETE CASCADE,
  sport TEXT NOT NULL,
  position TEXT,
  current_team TEXT,
  organization TEXT,
  coach_name TEXT,
  season TEXT, -- e.g. "Spring 2025", "Fall 2024-25"
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_athlete_sports_athlete_id ON athlete_sports(athlete_id);

-- ============================================================
-- 4. ATHLETE EVENTS (linked from HomeHuddle calendar)
-- ============================================================
CREATE TABLE IF NOT EXISTS athlete_events (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  athlete_id UUID NOT NULL REFERENCES athletes(id) ON DELETE CASCADE,
  event_id TEXT, -- reference to HomeHuddle calendar event ID
  event_title TEXT NOT NULL,
  event_type TEXT CHECK (event_type IN ('game','practice','tournament','camp','clinic','tryout','school','other')),
  sport TEXT,
  team TEXT,
  start_time TIMESTAMPTZ,
  end_time TIMESTAMPTZ,
  location TEXT,
  source TEXT DEFAULT 'homehuddle', -- where event came from
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_athlete_events_athlete_id ON athlete_events(athlete_id);
CREATE INDEX idx_athlete_events_start_time ON athlete_events(start_time);

-- ============================================================
-- 5. ATHLETE GOALS
-- ============================================================
CREATE TABLE IF NOT EXISTS athlete_goals (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  athlete_id UUID NOT NULL REFERENCES athletes(id) ON DELETE CASCADE,
  goal_title TEXT NOT NULL,
  goal_description TEXT,
  category TEXT CHECK (category IN ('skill','fitness','academic','mental','team','other')),
  target_date DATE,
  progress_status TEXT DEFAULT 'not_started' CHECK (progress_status IN ('not_started','in_progress','achieved','paused')),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_athlete_goals_athlete_id ON athlete_goals(athlete_id);

-- ============================================================
-- 6. ATHLETE STATS
-- ============================================================
CREATE TABLE IF NOT EXISTS athlete_stats (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  athlete_id UUID NOT NULL REFERENCES athletes(id) ON DELETE CASCADE,
  sport TEXT NOT NULL,
  stat_name TEXT NOT NULL,  -- e.g. "Batting Average", "40-yard dash", "Points per game"
  stat_value TEXT NOT NULL, -- flexible string to support all types
  season TEXT,
  recorded_at DATE DEFAULT CURRENT_DATE,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_athlete_stats_athlete_id ON athlete_stats(athlete_id);

-- ============================================================
-- 7. ATHLETE VIDEOS
-- ============================================================
CREATE TABLE IF NOT EXISTS athlete_videos (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  athlete_id UUID NOT NULL REFERENCES athletes(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  sport TEXT,
  category TEXT CHECK (category IN ('highlight','game_film','drill','evaluation','other')),
  video_url TEXT NOT NULL,
  thumbnail_url TEXT,
  notes TEXT,
  ai_analysis_status TEXT DEFAULT 'not_submitted' CHECK (ai_analysis_status IN ('not_submitted','pending','processing','complete','failed')),
  ai_analysis_notes TEXT,
  is_public BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_athlete_videos_athlete_id ON athlete_videos(athlete_id);

-- ============================================================
-- 8. COACH CONNECTIONS (placeholder for CoachesHuddle)
-- ============================================================
CREATE TABLE IF NOT EXISTS coach_connections (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  athlete_id UUID NOT NULL REFERENCES athletes(id) ON DELETE CASCADE,
  coach_id UUID, -- future reference to coaches table
  coach_name TEXT,
  coach_email TEXT,
  sport TEXT,
  organization TEXT,
  connection_status TEXT DEFAULT 'pending' CHECK (connection_status IN ('pending','active','inactive','declined')),
  permissions JSONB DEFAULT '{"view_profile": true, "view_stats": true, "view_videos": false, "recommend_goals": false}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_coach_connections_athlete_id ON coach_connections(athlete_id);

-- ============================================================
-- ROW LEVEL SECURITY (RLS)
-- Enable for production; families can only see their own data
-- ============================================================

ALTER TABLE families ENABLE ROW LEVEL SECURITY;
ALTER TABLE athletes ENABLE ROW LEVEL SECURITY;
ALTER TABLE athlete_sports ENABLE ROW LEVEL SECURITY;
ALTER TABLE athlete_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE athlete_goals ENABLE ROW LEVEL SECURITY;
ALTER TABLE athlete_stats ENABLE ROW LEVEL SECURITY;
ALTER TABLE athlete_videos ENABLE ROW LEVEL SECURITY;
ALTER TABLE coach_connections ENABLE ROW LEVEL SECURITY;

-- Example RLS policy (adjust auth.uid() to match your HomeHuddle auth approach)
-- Families can only access their own family record
CREATE POLICY "families_own_access" ON families
  FOR ALL USING (auth.uid()::text = id::text);

-- Athletes visible to their family
CREATE POLICY "athletes_family_access" ON athletes
  FOR ALL USING (
    family_id IN (SELECT id FROM families WHERE auth.uid()::text = id::text)
  );

-- Cascade policy pattern for child tables (apply same logic)
CREATE POLICY "athlete_sports_access" ON athlete_sports
  FOR ALL USING (
    athlete_id IN (
      SELECT a.id FROM athletes a
      JOIN families f ON f.id = a.family_id
      WHERE auth.uid()::text = f.id::text
    )
  );

CREATE POLICY "athlete_events_access" ON athlete_events
  FOR ALL USING (
    athlete_id IN (
      SELECT a.id FROM athletes a
      JOIN families f ON f.id = a.family_id
      WHERE auth.uid()::text = f.id::text
    )
  );

CREATE POLICY "athlete_goals_access" ON athlete_goals
  FOR ALL USING (
    athlete_id IN (
      SELECT a.id FROM athletes a
      JOIN families f ON f.id = a.family_id
      WHERE auth.uid()::text = f.id::text
    )
  );

CREATE POLICY "athlete_stats_access" ON athlete_stats
  FOR ALL USING (
    athlete_id IN (
      SELECT a.id FROM athletes a
      JOIN families f ON f.id = a.family_id
      WHERE auth.uid()::text = f.id::text
    )
  );

CREATE POLICY "athlete_videos_access" ON athlete_videos
  FOR ALL USING (
    athlete_id IN (
      SELECT a.id FROM athletes a
      JOIN families f ON f.id = a.family_id
      WHERE auth.uid()::text = f.id::text
    )
  );

CREATE POLICY "coach_connections_access" ON coach_connections
  FOR ALL USING (
    athlete_id IN (
      SELECT a.id FROM athletes a
      JOIN families f ON f.id = a.family_id
      WHERE auth.uid()::text = f.id::text
    )
  );

-- Public athlete profiles (read-only for anonymous)
CREATE POLICY "athletes_public_read" ON athletes
  FOR SELECT USING (is_public = TRUE);

CREATE POLICY "athlete_videos_public_read" ON athlete_videos
  FOR SELECT USING (is_public = TRUE);

-- ============================================================
-- SAMPLE SEED DATA (optional for testing)
-- ============================================================

-- INSERT INTO families (parent_name, email, phone, plan_type) VALUES
--   ('Sarah Johnson', 'sarah@example.com', '716-555-0101', 'founding');

-- ============================================================
-- NOTES FOR HOMEHUDDLE INTEGRATION
-- ============================================================
-- 1. families.id should map to your existing HomeHuddle user/family ID
--    OR use email as the join key if IDs differ.
-- 2. athlete_events.event_id references HomeHuddle calendar event IDs.
--    Maintain the same event ID format used in HomeHuddle.
-- 3. Auth tokens from HomeHuddle login should pass through to Supabase
--    via the same JWT/session mechanism already in place.
-- ============================================================
